package com.example.assets_hoa;

public class reference_hoa {

    private String      hoa_name;

    public reference_hoa(String name) {
        this.hoa_name = name;
    }

    public String getHoa_name() {
        return hoa_name;
    }
}
